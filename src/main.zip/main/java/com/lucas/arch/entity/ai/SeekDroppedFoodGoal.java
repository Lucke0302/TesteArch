package com.lucas.arch.entity.ai;

import com.lucas.arch.registry.ModTags;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.item.ItemEntity;

import java.util.EnumSet;
import java.util.List;

public class SeekDroppedFoodGoal extends Goal {
    private final PathfinderMob mob;
    private ItemEntity targetItem;
    private final double speedModifier;
    private final double searchRadius;

    public SeekDroppedFoodGoal(PathfinderMob mob, double speedModifier, double searchRadius) {
        this.mob = mob;
        this.speedModifier = speedModifier;
        this.searchRadius = searchRadius;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        List<ItemEntity> items = this.mob.level().getEntitiesOfClass(
                ItemEntity.class,
                this.mob.getBoundingBox().inflate(this.searchRadius),
                item -> item.getItem().is(ModTags.Items.CARNIVORE_FOOD)
        );

        if (items.isEmpty()) {
            return false;
        }

        this.targetItem = items.get(0);
        return true;
    }

    @Override
    public void start() {
        this.mob.getNavigation().moveTo(this.targetItem, this.speedModifier);
    }

    @Override
    public void tick() {
        if (this.targetItem != null && this.targetItem.isAlive()) {
            this.mob.getNavigation().moveTo(this.targetItem, this.speedModifier);
            
            if (this.mob.distanceToSqr(this.targetItem) < 2.5) {
                this.targetItem.discard(); 
            }
        }
    }

    @Override
    public boolean canContinueToUse() {
        return this.targetItem != null && this.targetItem.isAlive() && !this.mob.getNavigation().isDone();
    }
}