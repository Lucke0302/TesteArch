package com.lucas.arch;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.component.WrittenBookContent;
import net.minecraft.server.network.Filterable;
import net.minecraft.network.chat.Component;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.level.ServerPlayer;
import java.util.List;

public class ArcheologyUnnoficial implements ModInitializer {
    public static final String MOD_ID = "archeologyunnoficial";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModConfig.load();
        ModDataComponentTypes.registerDataComponentTypes();
        
        ModBlocks.registerModBlocks();
        ModBlockEntities.registerBlockEntities();
        ModMenuTypes.registerMenuTypes();
        
        ModItems.registerModItems();
        ModLootTableModifiers.modifyLootTables();

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer player = handler.getPlayer();
            
            if (player.addTag("received_arch_guide")) {
                
                ItemStack guideBook = new ItemStack(Items.WRITTEN_BOOK);

                List<Filterable<Component>> pages = List.of(
                    Filterable.passThrough(Component.literal("§1§lGuia Arqueologico\n\n§8Bem-vindo ao §2Archeology Unofficial§8!\n\nEste livro contem nossos registros iniciais sobre a extracao de DNA antigo e restauracao fossil.")),
                    Filterable.passThrough(Component.literal("§1§lMesa de Limpeza\n\n§8A maquina principal. Ela requer:\n- §bAgua§8 (max 10 baldes)\n- §6Combustivel\n\n§8Cada processo leva 10s (200 ticks) e consome 1 balde de agua.")),
                    Filterable.passThrough(Component.literal("§1§lOs Fosseis\n\n§8Ate o momento, catalogamos 4 matrizes base:\n\n- Planta\n- Reptil\n- Mamifero\n- Peixe\n\nPurifique-os na Mesa.")),
                    Filterable.passThrough(Component.literal("§1§lExtracao de DNA\n\n§8Ha apenas 30% de chance de sucesso. O resultado e um DNA puro (40% a 85%).\n\nFalhas destroem o material (areia, cascalho, osso ou carvao)."))
                );

                WrittenBookContent bookContent = new WrittenBookContent(
                    Filterable.passThrough("Guia de Arqueologia"), 
                    "Lucas.Moraes",
                    0,
                    pages,
                    false
                );

                guideBook.set(DataComponents.WRITTEN_BOOK_CONTENT, bookContent);
                player.getInventory().add(guideBook);
            }
        });
    }

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    
}